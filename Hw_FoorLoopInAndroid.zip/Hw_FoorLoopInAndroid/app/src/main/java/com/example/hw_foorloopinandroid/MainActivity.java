package com.example.hw_foorloopinandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText userInput1,userInput2;
    Button button, buttonEven, buttonOdd;
    TextView tvDisplay, tvDisplayEven, tvDisplayOdd ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userInput1 = findViewById(R.id.userInput1);
        userInput2 = findViewById(R.id.userInput2);
        button = findViewById(R.id.button);
        buttonEven = findViewById(R.id.buttonEven);
        buttonOdd=findViewById(R.id.buttonOdd);
        tvDisplay = findViewById(R.id.tvDisplay);
        tvDisplayEven = findViewById(R.id.tvDisplayEven);
        tvDisplayOdd = findViewById(R.id.tvDisplayOdd);





       button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               int up1= Integer.parseInt(userInput1.getText().toString());
               int up2= Integer.parseInt(userInput2.getText().toString());
               tvDisplay.setText("");
               for (int i = up1; i <=up2 ; i++) {
                   tvDisplay.append(" "+ i);

               }

           }

       });




       buttonEven.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               int up1= Integer.parseInt(userInput1.getText().toString());
               int up2= Integer.parseInt(userInput2.getText().toString());
               tvDisplayEven.setText("");
               for (int i = up1; i <=up2 ; i++) {

                   if (i%2 == 0) tvDisplayEven.append(" "+i);

               }


           }
       });




      buttonOdd.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {

              int up1= Integer.parseInt(userInput1.getText().toString());
              int up2= Integer.parseInt(userInput2.getText().toString());

              tvDisplayOdd.setText("");
              for (int i = up1; i <=up2 ; i++) {

                  if (i%2 != 0) tvDisplayOdd.append(" "+i);

              }


          }
      });

    }

}